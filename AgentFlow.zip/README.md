# AgentFlow

create virtual environment
```bash
python -m venv .venv
```
activate virtual environment
```bash
source .venv/bin/activate
```
install dependencies
```bash
pip install -r requirements.txt
```


# run the agent
```bash

python3 agents.py
python3 .\main.py

```